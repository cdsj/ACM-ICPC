#include<iostream>
#include<cstring>
#include<algorithm>
#include<map>
#include<queue>
#include<cmath>
#include<string>
#include<stdio.h>
#include<list>
#include<ctime>
#include<vector>
using namespace std;
const int cs=1e9+7;
int ks;
map<int,int>id;
int pr[1000000];
vector<vector<int> >a;
vector<int> ss;
int fid(vector<int>& a)
{
	int da=0;
	for(int i=0;i<ss.size();i++)
	{
		if(i)da*=ss[i]+1;
		da+=a[i];
	}
	return da;
}
void dfs(vector<int> s)
{
	sort(s.begin(),s.end());
	int k=fid(s);
	//for(int i=0;i<s.size();i++)
	//	cout<<s[i];cout<<"   ->  "<<k<<endl;
	if(id[k])return ;
	id[k]=a.size()+1;
	a.push_back(s);
	for(int i=0;i<s.size();i++)
	{
		if(s[i])
		{
			vector<int> ts=s;
			ts[i]--;
			dfs(ts);
		}
	}
}
int pt(vector<int>a,vector<int> b)
{
	int aa=0,bb=0;
	for(int i=0;i<a.size();i++)
		aa+=a[i],bb+=b[i];
	return aa>bb;
}
long long dp[20][2][20][2000];
void zy(long long &a,long long b)
{
	a+=b;
	a%=cs;
}
long long c[123][123];
int main()
{
//	freopen("in.txt","r",stdin);
//	freopen("out.txt","w",stdout);
	double tsd=clock();
	c[0][0]=1;
	for(int i=0;i<100;i++)
		for(int q=0;q<=i;q++)
			zy(c[i+1][q],c[i][q]),zy(c[i+1][q+1],c[i][q]);
	int ind=0;
	for(long long  i=2;i<1e6;i++)
	{
		if(!pr[i])
		{
			pr[ind++]=i;
			for(long long q=i*i;q<1e6;q+=i)
				pr[q]=1;
		}
	}
	double s=1;
	int n;
	while(cin>>n)
	{
		double fk=1;
		map<int,int>mp;
		a.clear();
		for(int i=0;i<n;i++)
		{
			int x;
			cin>>x;
			fk*=x;
			for(int i=0;x!=1;i++)
			{
				while(x%pr[i]==0)
				{
					x/=pr[i],mp[i]++;
				}
			}
		}
		vector<int>s;
		for(map<int,int>::iterator it=mp.begin();it!=mp.end();++it)
		{
			s.push_back(it->second);
		}

		sort(s.begin(),s.end());
		ss=s;
		id.clear();
		dfs(s);
		sort(a.begin(),a.end(),pt);
		for(int i=0;i<a.size();i++)
			id[fid(a[i])]=i;
		//cout<<"                                        "<<a.size()<<endl;
		memset(dp,0,sizeof(dp));		
		dp[0][0][s.size()-1][0]=1;
		vector<int>ts;		
		double fk2=1;
		for(int i=0;i<n;i++)
		{
			for(int z=0;z<2;z++)
				for(int q=s.size();q--;)
					for(int k=0;k<a.size();k++)
					{
						if(!dp[i][z][q][k])
							continue;
						int l=q;
						while(l-1>=0&&a[k][l-1]==a[k][q])
							l--;
						if(l)
							zy(dp[i][z][l-1][k],dp[i][z][q][k]);
						else 
						{
							if(z&1)
								zy(dp[i+1][0][s.size()-1][k],dp[i][z][q][k]);
						}
						if(a[k][q]==0)continue;
						ts=a[k];
						for(int j=l;j<=q;j++)
						{
							ts[j]--;
							zy(dp[i][1][j][id[fid(ts)]],dp[i][z][q][k]*c[q-l+1][j-l+1]);
						}

					}
		}
		cout<<dp[n][0][s.size()-1][a.size()-1]<<endl;


	}
	//cout<<(clock()-tsd)/1000.0<<endl;
}