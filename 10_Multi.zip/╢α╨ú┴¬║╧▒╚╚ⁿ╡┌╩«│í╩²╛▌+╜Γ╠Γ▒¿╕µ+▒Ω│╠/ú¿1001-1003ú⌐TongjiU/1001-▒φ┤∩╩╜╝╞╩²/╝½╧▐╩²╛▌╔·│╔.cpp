#include<iostream>
#include<cstring>
#include<algorithm>
#include<map>
#include<queue>
#include<cmath>
#include<string>
#include<stdio.h>
#include<list>
#include<vector>
using namespace std;
int pr[1231];
struct A{vector<int> a;double s;}e,te;
struct P{int p[100],n;double s;}p;
double eps=1e-8;
map<long long,A>mp;
void cf(P &p,int k)
{	
	p.p[p.n]=0;
	for(int i=0;i<p.n;i++)
		p.p[i]*=k;
	for(int i=0;i<p.n;i++)
		p.p[i+1]+=p.p[i]/10,p.p[i]%=10;
	while(p.p[p.n])
	{
		p.p[p.n+1]=p.p[p.n]/10;
		p.p[p.n]%=10;
		p.n++;
	}
}
P qiu(A &a)
{
	P p;
	p.n=1;
	p.p[0]=1;
	for(int i=0;i<a.a.size();i++)
		for(int q=0;q<a.a[i];q++)
			cf(p,pr[i]);
	return p;
}
//      a<=b
int pt(P a,P b)
{
	if(a.n!=b.n)
	{
		return a.n<b.n;
	}
	for(int i=a.n;i--;)
	{
		if(a.p[i]!=b.p[i])
			return a.p[i]<b.p[i];
	}
	return 1;
}
//      a<=b
int pt(A &a,A &b)
{
	if(a.s<b.s*(1-eps))return 1;
	if(b.s<a.s*(1-eps))return 0;
	return pt(qiu(a),qiu(b));
}
void ins(long long k,A &e)
{
	if(e.s>p.s*(1+eps)|| (e.s>p.s*(1-eps)&&!pt(qiu(e),p)))
		return ;
	map<long long,A>::iterator it=mp.lower_bound(k);
	if(it!=mp.end()&&pt(it->second,e))return ;	
	mp[k]=e;
	while(1)
	{
		it=mp.find(k);
		if(it==mp.begin())break;
		--it;
		if(pt(e,it->second))
			mp.erase(it);
		else break;
	}
}
void crt()
{
	for(int i=0;i<100;i++)
	{
		string a;
		a+=(char)(rand()%9+'1');
		int n=rand()%70+9;
		if(i&1)n=79;
		for(int i=0;i<n;i++)
			a+=(char)(rand()%10+'0');
		cout<<a<<endl;
	}
}
int main()
{
	//freopen("in.txt","r",stdin);
	//freopen("out.txt","w",stdout);
	//crt();return 1;
	int ind=0;
	for(int i=2;i<1e3;i++)
	{
		if(pr[i]==0)
		{
			pr[ind++]=i;
			for(int q=i*i;q<1e3;q+=i)
				pr[q]=1;
		}
	}
	string s;
	while(cin>>s)
	{
		mp.clear();
		reverse(s.begin(),s.end());
		p.n=s.size();
		p.s=0;
		for(int i=0;i<s.size();i++)
		{
			p.p[i]=s[i]-'0';
			p.s+=p.p[i]*pow(10.0,i);
		}
		e.a.clear();
		e.s=1;
		mp[1]=e;
		map<long long,A>::iterator it;
		long long k,tk;
		while(mp.size())
		{
			it=mp.begin();
			e=it->second;
			k=it->first;
			mp.erase(it);
			te=e;
			for(int i=0;i<e.a.size();i++)
			{
				if(i&&e.a[i]==e.a[i-1])continue;
				te.a[i]++;
				te.s=e.s*pr[i];
				ins(k/(e.a[i]+1)*(te.a[i]+1),te);
				te.a[i]--;
			}
			te.a.push_back(1);
			te.s=e.s*pr[e.a.size()];
			ins(k*2,te);
		}
		p=qiu(e);
		for(int i=p.n;i--;)
			cout<<p.p[i];
		cout<<' '<<k;cout<<endl;
		cout<<e.a.size()<<endl;;
		for(int i=0;i<e.a.size();i++)
		{
			if(i)cout<<" ";
			cout<<pow(pr[i]*1.0,e.a[i]+0.0);
		}
		cout<<endl;
	}
}