#include<iostream>
#include<cstring>
#include<algorithm>
#include<map>
#include<queue>
#include<cmath>
#include<string>
#include<stdio.h>
#include<list>
#include<vector>
using namespace std;
const int cs=333,cs2=1007;
struct HS{
	int a[1000],next[cs2],n,s[cs2],f[cs2],b[cs2];
	int bj;
	void clear()
	{
		bj=-1;
		memset(f,-1,sizeof(f));
		n=0;
	}
	void init()
	{
		bj=-1;
		for(int i=0;i<n;i++)
			f[b[i]%cs2]=-1;
		n=0;
	}
	int fd(int k)
	{
		if(bj!=-1)
		{
			if(bj==k)return cs;
			else return 0;
		}
		int fk=f[k%cs2];
		while(fk!=-1)
		{
			if(b[fk]==k)return s[fk];
			fk=next[fk];
		}
		return 0;
	}
	void ins(int k)
	{
		int fk=f[k%cs2];
		while(fk!=-1)
		{
			if(b[fk]==k)
			{
				s[fk]++;
				return ;
			}
			fk=next[fk];
		}
		s[n]=1;
		b[n]=k;
		next[n]=f[k%cs2];
		f[k%cs2]=n++;
	}
	void push()
	{
		if(bj!=-1)
		{
			for(int i=0;i<cs;i++)
				a[i]=bj;
			bj=-1;
		}
	}
	void crt()
	{
		init();
		for(int i=0;i<cs;i++)
			ins(a[i]);
	}
}hs[400];
int main()
{
//	freopen("in.txt","r",stdin);
//	freopen("out.txt","w",stdout);
	for(int i=0;i<400;i++)
		hs[i].clear();
	int n,m;
	while(cin>>n>>m)
	{
		for(int i=0;i<n;i++)
			scanf("%d",&hs[i/cs].a[i%cs]);
		for(int i=0;i*cs<n;i++)
			hs[i].crt();
		//for(int i=0;i<n;i++)
		//	cout<<hs[i/cs].a[i%cs]<<"  ";cout<<endl;
		while(m--)
		{
			int a,l,z,r;
			scanf("%d%d%d%d",&a,&l,&r,&z);
			if(a==1)
			{
				if(l/cs==r/cs)
				{
					hs[l/cs].push();
					for(int i=l;i<=r;i++)
						hs[l/cs].a[i%cs]=z;
					hs[l/cs].crt();
					continue;
				}
				hs[l/cs].push();
				hs[r/cs].push();
				for(int q=l%cs;q<cs;q++)
					hs[l/cs].a[q]=z;
				for(int q=0;q<=r%cs;q++)
					hs[r/cs].a[q]=z;
				hs[l/cs].crt();
				hs[r/cs].crt();
				for(int i=l/cs+1;i<r/cs;i++)
					hs[i].bj=z;
			}else{
				int da=0;
				if(l/cs==r/cs)
				{
					hs[l/cs].push();
					hs[l/cs].crt();
					for(int i=l;i<=r;i++)
					{
						//cout<<hs[l/cs].a[i%cs]<<"  ";
						da+=(hs[i/cs].a[i%cs]==z);
					}
					printf("%d\n",da);
					continue;
				}
				hs[l/cs].push();
				hs[r/cs].push();
				hs[l/cs].crt();
				hs[r/cs].crt();
				for(int q=l%cs;q<cs;q++)
					da+=(hs[l/cs].a[q]==z);
				for(int q=0;q<=r%cs;q++)
					da+=(hs[r/cs].a[q]==z);
				//cout<<l<<"  "<<r<<"  "<<l/cs+1<<"  "<<r/cs<<endl;
				for(int i=l/cs+1;i<r/cs;i++)
				{
					//cout<<i<<" ";
					da+=hs[i].fd(z);
				}printf("%d\n",da);
			}
		}
	}
}
