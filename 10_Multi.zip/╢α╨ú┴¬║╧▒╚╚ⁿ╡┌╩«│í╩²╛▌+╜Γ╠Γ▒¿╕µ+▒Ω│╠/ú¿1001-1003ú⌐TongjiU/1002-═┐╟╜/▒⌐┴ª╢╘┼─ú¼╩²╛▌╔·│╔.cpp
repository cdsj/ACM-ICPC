#include<iostream>
#include<cstring>
#include<algorithm>
#include<map>
#include<queue>
#include<cmath>
#include<string>
#include<stdio.h>
#include<list>
#include<vector>
using namespace std;
int a[123232];
void crt()
{
	int n,m;
	int cs=10;
	n=1000,m=1000;
	cout<<n<<" "<<m<<endl;
	for(int i=0;i<n;i++)
	{
		if(i)
			cout<<' ';
		cout<<rand()*rand()%cs ;
	}cout<<endl;
	while(m--)
	{
		cout<<rand()%2+1<<' ';
		int l=rand()*rand()%n,r=rand()*rand()%n;
		if(l>r)swap(l,r);
		//if(rand()%4==0)l=0,r=n-1;
		cout<<l<<' '<<r<<' '<<rand()*rand()%cs<<endl;
	}
}
int main()
{
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);
	//for(int i=0;i<10;i++)crt();return 1;
	int n,m;
	while(cin>>n>>m)
	{
		for(int i=0;i<n;i++)
			cin>>a[i];
		while(m--)
		{
			int s,l,r,z;
			cin>>s>>l>>r>>z;
			if(s==1)
			{
				for(int i=l;i<=r;i++)
					a[i]=z;
			}else{
				int da=0;
				for(int i=l;i<=r;i++)
					da+=(a[i]==z);
				cout<<da<<'\n';
			}
		}
	}
}