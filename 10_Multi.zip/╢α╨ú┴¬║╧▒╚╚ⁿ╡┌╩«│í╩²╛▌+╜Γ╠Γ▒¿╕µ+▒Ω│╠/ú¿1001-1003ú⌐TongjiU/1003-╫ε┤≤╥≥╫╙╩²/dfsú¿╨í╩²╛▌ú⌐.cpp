#include<iostream>
#include<cstring>
#include<algorithm>
#include<map>
#include<queue>
#include<cmath>
#include<string>
#include<stdio.h>
#include<list>
#include<vector>
using namespace std;
struct A{int n,a[123];long long s;}p,da;
int pr[1231];
int js[1231];
void cf(A &a,int k)
{
	a.a[a.n]=0;
	for(int i=0;i<a.n;i++)
		a.a[i]*=k;
	for(int i=0;i<a.n;i++)
		a.a[i+1]+=a.a[i]/10,a.a[i]%=10;
	while(a.a[a.n])
	{
		a.a[a.n+1]=a.a[a.n]/10;
		a.a[a.n]%=10;
		a.n++;
	}
}
int pt(A &a,A &b)
{
	if(a.n!=b.n)return a.n>b.n;
	for(int i=a.n;i--;)
		if(a.a[i]!=b.a[i])
			return a.a[i]>b.a[i];
	return 0;
}
int fk=0;
void ot(A a)
{
	for(int i=a.n;i--;)
		cout<<a.a[i];
	//cout<<endl;
}
void gao(int n,long long k)
{
	//printf("%d\n",fk++);
	if(k<da.s)return ;
	A e;
	e.n=1;
	e.a[0]=1;
	e.s=k;
	for(int i=0;i<=n;i++)
		for(int q=0;q<js[i];q++)
			cf(e,pr[i]);
	if(pt(e,p))return ;	
	//ot(e);
	//cout<<' ';cout<<e.s<<endl;
	if(e.s>da.s||pt(da,e))
	{
		da=e;
	}
}
void dfs(int i,int n,double s,long long k)
{
	for(int q=1;q<=n;q++)
	{
		s/=pr[i];	
		js[i]=q;
		if(s<0.9999)
		{
			js[i]--;
			gao(i,k*q);
			return ;
		}
		dfs(i+1,q,s,k*(q+1));
	}
}
int main()
{
//	freopen("in.txt","r",stdin);
//	freopen("out.txt","w",stdout);
	int ind=0;
	for(int i=2;i<1e3;i++)
	{
		if(pr[i]==0)
		{
			pr[ind++]=i;
			for(int q=i*i;q<1e3;q+=i)
				pr[q]=1;
		}
	}
	string s;
	while(cin>>s)
	{
		double k=0;
		reverse(s.begin(),s.end());
		p.n=s.size();
		for(int i=0;i<s.size();i++)
		{
			p.a[i]=s[i]-'0';
			k+=p.a[i]*pow(10.0,i);
		}
		da.n=1;
		da.a[0]=1;
		da.s=1;
		dfs(0,100,k,1);
		for(int i=da.n;i--;)
			cout<<da.a[i];
		cout<<' '<<da.s<<endl;
	}

}