#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
const double eps=1e-8;
const int MID=200010;
bool vis[220020];
int num[210];
int que[1000000];
int p;
int t,d,n;
void input()
{
    double tmp;
    scanf("%lf %d",&tmp,&n);

    if(tmp>0) d=int(tmp*10000+eps);
    else d=int(tmp*10000-eps);

    for(int i=0; i<n; i++)
    {
        scanf("%lf",&tmp);
        if(tmp>0) num[i]=int(tmp*10000+eps);
        else num[i]=int(tmp*10000-eps);
    }
}
void init()
{
    memset(vis,false,sizeof(vis));
    que[0]=0;
    p=1;
    vis[MID]=true;
}
void solve()
{
    sort(num,num+n);
    for(int i=0; i<n; i++)
    {
        int tp=p;
        for(int j=0; j<tp; j++)
        {
            if(num[i]+que[j]<20000  && !vis[num[i]+que[j]+MID])
            {
                que[p++]=num[i]+que[j];
                vis[num[i]+que[j]+MID]=true;
            }
        }
    }

    int ans=0;
    for(int i=0;;i++)
    {
        if(d-i>-200000 && vis[d-i+MID])
        {
            ans=d-i;
            break;
        }
        if(d+i<20000 && vis[d+i+MID])
        {
            ans=d+i;
            break;
        }
    }
    printf("%.4f\n",ans*0.0001);
}
int main()
{
 //   freopen("D:\\data.in","r",stdin);
 //   freopen("D:\\data.out","w",stdout);
    scanf("%d",&t);
    while(t--)
    {
        input();
        init();
        solve();
    }
}
