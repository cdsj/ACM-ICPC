#include<cstdio>
#include<cmath>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const double eps=1e-8;
int main()
{
freopen("D:\\data.txt","w",stdout);
//freopen("D:\\");
cout<<5<<endl;

//CASE 1:
cout<<"-0.9900 105"<<endl;
for(int i=0; i<100; i++)
cout<<"-0.1000"<<endl;
for(int i=0; i<4; i++)
cout<<"2.0000"<<endl;
cout<<"1.0100"<<endl;

//CASE 2:
cout<<"-0.9900 105"<<endl;
for(int i=0; i<4; i++)
cout<<"2.0000"<<endl;
cout<<"1.0100"<<endl;
for(int i=0; i<100; i++)
cout<<"-0.1000"<<endl;

//CASE 3:
cout<<"0.9000 200"<<endl;
for(int i=0;i<190;i++)
cout<<"-0.1000"<<endl;
for(int i=0;i<9;i++)
cout<<"2.0000"<<endl;
cout<<"1.9000"<<endl;

//CASE 4：
cout<<"0.0010 200"<<endl;
for(int i=0;i<190;i++)
cout<<"0.1000"<<endl;
for(int i=0;i<9;i++)
cout<<"2.0000"<<endl;
cout<<"0.0009"<<endl;

//CASE 5：
cout<<"-0.0001 200"<<endl;
for(int i=0;i<190;i++)
cout<<"1.0000"<<endl;
for(int i=0;i<9;i++)
cout<<"2.0000"<<endl;
cout<<"-0.0002"<<endl;
}
