#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define MAX 221000
bool DP[MAX]={0};
#define dp(x) DP[x+200000]
int main()
{
//    freopen("data.in","r",stdin);
 //   freopen("data.out","w",stdout);
    int T;
    scanf("%d",&T);
    while(T--)
    {
        memset(DP,0,sizeof(DP));
        double d;
        int n;
        scanf("%lf %d",&d,&n);
        int a[220];
        for(int i=0;i<n;i++)
        {
            double temp;
            scanf("%lf",&temp);
            if(temp>0)a[i]=temp*10000+1e-8;
            else a[i]=temp*10000-1e-8;
        }
        sort(a,a+n);
        int des;
        if(d>0) des=d*10000+1e-8;
        else des=d*10000-1e-8;
        dp(0)=1;
        for(int i=0;i<n;i++)
        {
            if(a[i]>0)
            {
                for(int j=20000-1;j>-200000;j--)
                if(j+a[i]<20000 && j+a[i]>-200000 &&dp(j))dp(j+a[i])=1;
            }
            else
            {
                for(int j=-200000+1;j<20000;j++)
                if(j+a[i]<20000 && j+a[i]>-200000 &&dp(j))dp(j+a[i])=1;
            }
        }
        int k;
        for(k=0;k<MAX;k++)
        {
            if(des+k<20000 && dp(des+k)) break;
            if(des-k>-200000 && dp(des-k)) break;
        }
        if(dp(des-k))
        printf("%.4f\n",(double)(des-k)/10000);
        else printf("%.4f\n",(double)(des+k)/10000);
    }
    return 0;
}
