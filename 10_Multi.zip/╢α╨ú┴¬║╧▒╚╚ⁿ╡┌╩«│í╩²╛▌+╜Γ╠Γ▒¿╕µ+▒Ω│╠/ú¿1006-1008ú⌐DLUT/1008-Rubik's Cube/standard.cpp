#include<cstdio>
#include<cstring>
int loc[9],dir[9],locm[13],dirm[13],mid[7];
void init(){
    for(int i=1;i<=8;i++){
        loc[i]=i;
        dir[i]=0;
    }
    for(int i=1;i<=12;i++){
        locm[i]=i;
        dirm[i]=0;
    }
    for(int i=1;i<=6;i++){
        mid[i]=i;
    }
}
void spin(int ll,int a,int b,int c,int d,int id[],int l[]){
    if(id[l[a]]!=ll) id[l[a]]=3-ll-id[l[a]];
    if(id[l[b]]!=ll) id[l[b]]=3-ll-id[l[b]];
    if(id[l[c]]!=ll) id[l[c]]=3-ll-id[l[c]];
    if(id[l[d]]!=ll) id[l[d]]=3-ll-id[l[d]];
}
void change(int a,int b,int c,int d,int loc[]){
    loc[0]=loc[d];
    loc[d]=loc[c];
    loc[c]=loc[b];
    loc[b]=loc[a];
    loc[a]=loc[0];
}
int main(){
//    freopen("data.in","r",stdin);
 //   freopen("data.out","w",stdout);
    char s[200];
    int len,i;
    bool jud=0;
    while(~scanf("%s",s)){
        if(jud) printf("\n");
        jud=1;
        init();
        len=strlen(s);
        for(i=0;i<len;i++){
            switch(s[i]){
                case'U': change(4,3,2,1,loc);change(4,3,2,1,locm);spin(0,4,3,2,1,dir,loc);spin(0,4,3,2,1,dirm,locm);break;
                case'u': change(1,2,3,4,loc);change(1,2,3,4,locm);spin(0,4,3,2,1,dir,loc);spin(0,4,3,2,1,dirm,locm);break;
                case'R': change(2,3,7,6,loc);change(9,2,10,6,locm);spin(1,2,3,7,6,dir,loc);spin(1,9,2,10,6,dirm,locm);break;
                case'r': change(2,6,7,3,loc);change(9,6,10,2,locm);spin(1,2,3,7,6,dir,loc);spin(1,9,2,10,6,dirm,locm);break;
                case'L': change(1,5,8,4,loc);change(4,12,8,11,locm);spin(1,1,5,8,4,dir,loc);spin(1,4,12,8,11,dirm,locm);break;
                case'l': change(1,4,8,5,loc);change(8,12,4,11,locm);spin(1,1,5,8,4,dir,loc);spin(1,4,12,8,11,dirm,locm);break;
                case'D': change(5,6,7,8,loc);change(5,6,7,8,locm);spin(0,5,6,7,8,dir,loc);spin(0,5,6,7,8,dirm,locm);break;
                case'd': change(8,7,6,5,loc);change(8,7,6,5,locm);spin(0,5,6,7,8,dir,loc);spin(0,5,6,7,8,dirm,locm);break;
                case'F': change(1,2,6,5,loc);change(1,9,5,12,locm);spin(2,1,2,5,6,dir,loc);spin(2,1,9,5,12,dirm,locm);break;
                case'f': change(2,1,5,6,loc);change(12,5,9,1,locm);spin(2,1,2,5,6,dir,loc);spin(2,1,9,5,12,dirm,locm);break;
                case'B': change(3,4,8,7,loc);change(3,11,7,10,locm);spin(2,3,4,8,7,dir,loc);spin(2,3,11,7,10,dirm,locm);break;
                case'b': change(3,7,8,4,loc);change(10,7,11,3,locm);spin(2,3,4,8,7,dir,loc);spin(2,3,11,7,10,dirm,locm);break;
                case'X': change(12,11,10,9,locm);change(2,6,4,5,mid);spin(0,12,11,10,9,dirm,locm);break;
                case'x': change(12,9,10,11,locm);change(2,5,4,6,mid);spin(0,12,11,10,9,dirm,locm);break;
                case'Y': change(1,3,7,5,locm);change(4,3,2,1,mid);spin(1,1,3,7,5,dirm,locm);break;
                case'y': change(5,7,3,1,locm);change(1,2,3,4,mid);spin(1,1,3,7,5,dirm,locm);break;
                case'Z': change(2,4,8,6,locm);change(1,6,3,5,mid);spin(2,2,4,8,6,dirm,locm);break;
                case'z': change(6,8,4,2,locm);change(5,4,6,1,mid);spin(2,2,4,8,6,dirm,locm);break;
            }
        }
        bool jud=1;
        for(i=1;i<=8&&jud;i++){
            if(loc[i]!=i||dir[i]!=0) jud=0;
        }
        for(int i=1;i<=12&&jud;i++){
            if(locm[i]!=i||dirm[i]!=0) jud=0;
        }
        for(int i=1;i<=6&&jud;i++){
            if(mid[i]!=i) jud=0;
        }
        if(jud) printf("Yes\n");
        else printf("No\n");
    }
    return 0;
}

