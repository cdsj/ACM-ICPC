#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<time.h>
using namespace std;
    bool road[100100];
int main() {
    freopen("input4.in","w",stdout);
    srand(time(0));
    int n,m;
    //n=rand()%5000+1;
    //m=(rand()*1007)%100000;
    n=5000;
    m=100000;
    printf("%d %d\n",n,m);
    int total=0;
    int t=rand()%n+1;
    while(m--)
    {
        printf("%d %d %d\n",rand()%n+1,rand()%n+1,rand()%100+1);
    }
    printf("%d %d %d\n",rand()%n+1,t,rand()%500+1);
	return 0;
}
