#include<iostream>
#include<queue>
#include<cstdio>
#include<ctime>
#include<cstring>
using namespace std;
const int N = 6000,M = 100000,INF = 1<<29;
struct point
 {
     int nk,u;
     point(int a = 0,int b = 0)
      {
         nk = a; u = b;
      }
 }tp;
struct
 {
     int u,v,w,next;
 }edge[M*5];
int head[N],num,n,m,f[55][N],s,t,k;
void add(int a,int b,int w)
 {
     edge[num].u = a;
     edge[num].v = b;
     edge[num].w = w;
     edge[num].next = head[a];
     head[a] = num++;
 }
void init()
 {
     int a,b,w;
     num = 0;
     memset(head,-1,sizeof(head));
     for(int i = 0;i <= n;i++)
      {
          for(int j = 0;j <= 50; j++)
          f[j][i] = INF;
      }
     for(int i = 0;i < m;i++)
      {
          scanf("%d%d%d",&a,&b,&w);
          add(a,b,w);
          add(b,a,w);
      }
     scanf("%d%d%d",&s,&t,&k);
     if(k % 10) k = k/10 +1;
     else k = k / 10;
 }
void SPFA()
 {
     int u,v,w,now_k,next_k;
     bool in[55][N] = {0};
     queue<point>q;
     q.push(point(0,s));
     in[0][s] = 1;
     f[0][s] = 0;
     while(!q.empty())
      {
          tp = q.front();
          q.pop();
          u = tp.u;
          now_k = tp.nk;
          in[now_k][u] = 0;
          for(int i = head[u];i != -1;i = edge[i].next)
           {
               v = edge[i].v;
               w = edge[i].w;
               if(now_k == k)
                next_k = k;
               else next_k = now_k+1;
               if(f[next_k][v] > f[now_k][u] + w)
                {
                    f[next_k][v] = f[now_k][u] + w;
                    if(!in[next_k][v])
                     {
                         q.push(point(next_k,v));
                         in[next_k][v] = true;
                     }
                }
           }
      }
     if(f[k][t] == INF)
      {
          printf("-1\n");
      }
     else printf("%d\n",f[k][t]);
 }
int main()
 {
     //freopen("input.in","r",stdin);
     //freopen("ans.txt","w",stdout);
     //clock_t start= clock(),end;
     while(scanf("%d%d",&n,&m) != EOF)
      {
          init();
          SPFA();
      }
      //end  = clock();
      //printf("%d \n",end-start);
 }
