#include<cstdio>
#include<cstring>
#include<queue>
#include<iostream>
using namespace std;
const int INF = 0xffffff;
const int MAX_SIDE = 1000010;
struct Side {
    int from,to,w;
} side[2*MAX_SIDE];
int node[5001];
int next[2*MAX_SIDE];
int H,K;
int s,t;
int n,m;
struct Shortest {
    int p;
    int sumLumber;
    int sumLength;
    bool vis;
    friend bool operator <(const Shortest &a,const Shortest &b) {
        return a.sumLength>=b.sumLength;
    }
} shortest[51][5001];
using namespace std;
priority_queue<Shortest>q;
int dij() {
    q.push(shortest[0][s]);
    Shortest front;
    while(!q.empty()) {
        front = q.top();
        q.pop();
        if(shortest[front.sumLumber][front.p].vis) continue;
        else shortest[front.sumLumber][front.p].vis=true;
        if(front.p==t&&front.sumLumber==K)break;
        for(int i=node[front.p]; i; i=next[i]) {
            if(front.sumLumber<K) {
                if(shortest[front.sumLumber][front.p].sumLength+side[i].w<\
                        shortest[front.sumLumber+1][side[i].to].sumLength) {
                            if(shortest[front.sumLumber+1][side[i].to].vis) continue;
                    shortest[front.sumLumber+1][side[i].to].sumLength=shortest[front.sumLumber][front.p].sumLength+side[i].w;
                    q.push(shortest[front.sumLumber+1][side[i].to]);
                }
            } else {
                if(shortest[K][front.p].sumLength+side[i].w<\
                        shortest[K][side[i].to].sumLength) {
                    if(shortest[K][side[i].to].vis) continue;
                    shortest[K][side[i].to].sumLength=shortest[K][front.p].sumLength+side[i].w;
                    q.push(shortest[K][side[i].to]);
                }
            }
        }
    }
    if(shortest[K][t].sumLength>=INF) return -1;
    return shortest[K][t].sumLength;
}
void ini() {
    memset(side,0,sizeof(side));
    memset(node,0,sizeof(node));
    memset(next,0,sizeof(next));
    for(int i=1; i<5001; i++) {
        for(int j=0; j<51; j++) {
            shortest[j][i].p=i;
            shortest[j][i].sumLumber=j;
            shortest[j][i].vis=false;
            shortest[j][i].sumLength=INF;
        }
    }
}
int main() {
    int from,to,w;
    //freopen("input.in","r",stdin);
    //freopen("output6.out","w",stdout);
    while(~scanf("%d%d",&n,&m)) {
        ini();
        for(int i=1; i<=m; i++) {
            scanf("%d%d%d",&from,&to,&w);
            side[i].from=from,side[i].to=to,side[i].w=w;
            side[i+m].from=to,side[i+m].to=from,side[i+m].w=w;
            next[i]=node[from];
            node[from]=i;
            next[i+m]=node[to];
            node[to]=i+m;
        }
        scanf("%d%d%d",&s,&t,&K);
        if(K%10==0)K=K/10;
        else K=K/10+1;
        shortest[0][s].sumLength=0;
        cout<<dij()<<endl;
    }
    return 0;
}
