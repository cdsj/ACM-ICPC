#include<cstdio>
int m,f[50010],a[50010],h[50010];
int main()
{
	freopen("data.in","r",stdin);
	freopen("data_baoli.out","w",stdout);
	int t,cas=0;
	scanf("%d",&t);
	while(t--)
	{
		printf("Case #%d:\n",++cas);
		scanf("%d",&m);
		for(int i=1;i<=m;i++)
		{
			scanf("%d%d",f+i,a+i);
			h[i]=0;
		}
		for(int k=0;k<m;k++)
		{
			int maxi=-1;
			for(int i=1;i<=m;i++)
				if(!h[i])
				{
					if(maxi==-1) maxi=i;
					else if(f[i]>f[maxi]) maxi=i;
				}
			printf(k==0?"%d":" %d",maxi);
			h[maxi]=1;
			for(int i=1;i<=m;i++) f[i]+=a[i];
		}
		puts("");
	}
	return 0;
}