#include<cstdio>
#include<queue>
using namespace std;
struct person{
	int f,ID;
	person(int a=0,int b=0):f(a),ID(b){}
	bool operator < (const person &b) const
	{
		return f==b.f?ID>b.ID:f<b.f;
	}
};
priority_queue<person> s[101];
int main()
{
//	freopen("data.in","r",stdin);
//	freopen("data_3.out","w",stdout);

	int T,cas=0,n;
	scanf("%d",&T);
	while(T--)
	{
		printf("Case #%d:\n",++cas);
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			int f,speed;
			scanf("%d%d",&f,&speed);
			s[speed].push(person(f,i));
		}
		for(int i=0;i<n;i++){
			int mx=-1,ID,ms;
			for(int speed=1;speed<=100;speed++)if(!s[speed].empty()){
				int tx=s[speed].top().f,tID=s[speed].top().ID;
				tx+=speed*i;
				if(tx>mx || tx==mx && tID<ID){
					ID=tID;
					ms=speed;
					mx=tx;
				}
			}
			printf(i?" %d":"%d",ID);
			s[ms].pop();
		}
		puts("");
	}
	return 0;
}
