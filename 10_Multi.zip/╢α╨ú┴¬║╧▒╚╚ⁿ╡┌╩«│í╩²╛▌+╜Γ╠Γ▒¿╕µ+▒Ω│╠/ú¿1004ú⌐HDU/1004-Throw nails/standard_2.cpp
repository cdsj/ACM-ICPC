#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

struct person
{
	int way,speed,id,isout;
	void input(int i)
	{
		scanf("%d%d",&way,&speed);
		id=i+1;
		isout=0;
	}
	inline void next(){way+=speed;}
	
	bool operator < (const person &b) const
	{
		if (speed!=b.speed) return b.speed<speed;
		if (way!=b.way) return b.way<way;
		return id<b.id;
	}
}p[100010];

int m;

int main()
{
//	freopen("data.in","r",stdin);
//	freopen("data_2.out","w",stdout);
	
	int T,cas=0;
	scanf("%d",&T);
	while(T--)
	{
		int out_num=0;//��¼�Ѿ��ж���ѡ������  
		printf("Case #%d:\n",++cas);
		
		scanf("%d",&m);
		for(int i=0;i<m;i++)
			p[i].input(i);
		sort(p,p+m);
		for(int i=0;i<m;i++)
		{
			bool flag=true;//��¼�Ƿ��ڵݼ�״̬ 
			int lasti=0, maxid, maxway;
			while(lasti<m && p[lasti].isout==1) lasti++;
			//if(lasti == m) break;
			maxid=lasti;
			maxway=p[lasti].way;
			p[lasti].next();
			
			for(int j=lasti+1;j<m;j++)
				if(p[j].isout==0)
				{
					if(p[j].way == maxway && p[j].id < p[maxid].id || p[j].way > maxway)
					{
						maxway=p[j].way;
						maxid=j;
					}
					p[j].next();
					if (p[j].way == p[lasti].way && p[j].speed < p[lasti].speed || p[j].way > p[lasti].way) flag=false;
					lasti=j;
				}
			printf(out_num==0?"%d":" %d",p[maxid].id);
			out_num++;
			p[maxid].isout=1;
			if (flag) break;
		}
		for(int i=0;i<m;i++)
			if (p[i].isout == 0)
			{
				printf(out_num == 0?"%d":" %d",p[i].id);
				out_num++;
			}
		puts("");
	}
	return 0;
}
