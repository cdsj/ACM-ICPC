#include <cstdlib>   
#include <cstdio>   
#include <cstring>   
#include <cmath>   
#include <queue>
#include <iostream>   
using namespace std;
typedef __int64 ll;
struct s{
	ll a;
	int b;
};
ll d[10];
void set(){
	ll m = 1;
	int i;
	for(i = 0; i < 10; i++){
		d[i] = m;
		m *= 10;
	}
}
int get(ll a){
	int m = 0;
	if(a == 0) return 1;
	while(a != 0){
	 	a /= 10;
		m ++;
	}
	return m;
}
int main()   
{   
	set();
	int t;
	scanf("%d",&t);
	while(t--){
		ll m = 54321;
		scanf("%I64d",&m);
	
		queue<s> q;

		s temp = {0,0};

		int n = get(m) ;
		q.push(temp);
		while(!q.empty()){
			s temp = q.front();
			if(temp.b == n) 	break;
			q.pop();
			int i;
			for(i = 0; i < 10; i++){
				s now ;
				now.a = temp.a + d[temp.b] * i;
				now.b = temp.b + 1;		

				if((now.a *now.a) % d[now.b] == m % d[now.b]) {
					q.push(now);
				}	


			}
		}


		ll min = d[9];
		while(!q.empty()){
			s temp = q.front();
			q.pop();
			if(min >temp.a) min = temp.a;
		}
		if(min == d[9]) printf("None\n");
		else printf("%I64d\n",min);
	}

    return 0;   
} 
