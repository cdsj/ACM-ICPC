#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
__int64 a[1000]={98121,97604,98049,98209,99201,96721,987654321,96784,54321,100000};
int main(){
	srand(time(0));
	int m = 100, i = 10, j;
	FILE *f1 = fopen("data.in","w");
	for(j = 0; j < m; i++, j++){
		a[i] =(__int64) j + 1;
	}
	double h;
	m = 300;
	double N = 899999999, M = 100000000;
	for(j = 0; j < m; i++, j++){
		h = rand()*N / RAND_MAX + M;
		a[i] =(__int64) h;
	}
	N = 89999999;M = 10000000; m = 200;
	for(j = 0; j < m; i++, j++){
		h = rand()*N / RAND_MAX + M;
		a[i] =(__int64) h;
	}
	N = 8999999;M = 1000000; m = 100;
	for(j = 0; j < m; i++, j++){
		h = rand()*N / RAND_MAX + M;
		a[i] =(__int64) h;
	}
	N = 899999;M = 100000; m = 100;
	for(j = 0; j < m; i++, j++){
		h = rand()*N / RAND_MAX + M;
		a[i] =(__int64) h;
	}
	N = 89999;M = 10000; m = 100;
	for(j = 0; j < m; i++, j++){
		h = rand()*N / RAND_MAX + M;
		a[i] =(__int64) h;
	}
	N = 8999;M = 1000; m = 10;
	for(j = 0; j < m; i++, j++){
		h = rand()*N / RAND_MAX + M;
		a[i] =(__int64) h;
	}
	fprintf(f1,"%d\n",i);
	for(j = 0; j < i ; j++){	
		fprintf(f1,"%I64d\n",a[j]);
	}
	fclose(f1);
	return 0;
}
