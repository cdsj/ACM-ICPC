#include <iostream>
#include <cassert>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

const int MAXN = 100010;

int ans[MAXN], n;

int main()
{
//	freopen("data.in", "r", stdin);
//	freopen("data.out", "w", stdout);

	
//	int start = clock();
	
	int T;	cin >> T;
	assert(T >= 1 && T <= 100);
	
	for(int cas = 1; cas <= T; ++ cas)
	{
		cin >> n;
		assert(n >= 1 && n <= 100000);
		cout << "Case #" << cas << ": " << n - (int)sqrt(n + 0.5) << endl;
		
		int D = (int)sqrt(n + 0.5), idx = 1;
		for(int i = 1; i <= n; ++ i)	ans[i] = i;
		for(int L = D - 1; L <= D; ++ L)
			for(int i = 1; i <= L; ++ i)
			{
				reverse(ans + idx, ans + idx + i);
				idx += i;	
			}
		
		for(int i = 1; i < n; ++ i)	printf("%d ", ans[i]);
		printf("%d\n", ans[n]);
	}
	
//	cout << clock() - start << endl;
	
	return 0;	
}
