#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
	freopen("data.in", "w", stdout);
	
	srand(20120817);
	
	int T = 99;	
	cout << T << endl;
	
	for(int i = 1; i <= 10; ++ i, -- T)	cout << i << endl;
	
	for(int i = 40; i < 82; ++ i, -- T)	cout << i << endl;
	
	for(int i = 400 - 10; i < 400 + 10; ++ i, -- T)	cout << i << endl;
	
	for(int i = 900 - 10; i < 900 + 10; ++ i, -- T)	cout << i << endl;
	
	T -= 2;
	puts("96100");//310^2
	puts("100000");
	
	while(T --)	cout << rand() % 1000 + 1000 << endl;
	

	return 0;	
}
