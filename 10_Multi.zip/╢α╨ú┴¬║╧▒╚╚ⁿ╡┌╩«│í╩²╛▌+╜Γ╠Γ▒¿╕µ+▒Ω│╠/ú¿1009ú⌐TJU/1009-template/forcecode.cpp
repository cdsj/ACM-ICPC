#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

const int MAXN = 100100;
int a[MAXN], cc[MAXN];
int m, n;

int find_next(int req, int cur) {
    for (int i = cur + 1 ; i < n ; i++) {
        if (a[i] == req) return i;
    }
    return n;
}

int main() {
    freopen("data.in","r",stdin);
    freopen("forcedata.out","w",stdout);
    while (scanf("%d%d",&n,&m) != EOF) {
        for (int i = 0 ; i < n ; i++)
            scanf("%d",&a[i]);
        for (int i = 0 ; i < m ; i++)
            cc[i] = i + 1;
        int ans = 0;
        for (int i = 0 ; i < n ; i++) {
            int j;
            for (j = 0 ; j < m ; j++)
                if (cc[j] == a[i]) break;
            if (j < m) {
                // in cache;
                continue;
            }
            ++ans;
            int this_next = find_next(a[i], i);
            int max_next = -1, max_itr;
            for (int itr = 0 ; itr < m ; ++itr) {
                int next = find_next(cc[itr], i);
                if (next > max_next) {
                    max_next = next;
                    max_itr = itr;
                }
            }
            if (max_next > this_next) {
                // replace
                cc[max_itr] = a[i];
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}
