#include <stdio.h>
#include <inttypes.h>
#include <list>
#include <map>
#include <set>
#include <vector>
#include <cassert>
using namespace std;

const int MAXN = 100010;
map<int,int> mp;
typedef pair<int,int> CacheNode;
typedef set<CacheNode> Cache;
typedef Cache::iterator CacheItr;
Cache cache;
map<int, CacheItr> pos_in_cache;

int req[MAXN], next[MAXN];
int main() {
 //   freopen("data.in","r",stdin);
 //   freopen("data.out","w",stdout);
    int n, m;
    while (scanf("%d%d",&n,&m) != EOF) {
        assert(n >= 1 && n <= 100000);
        assert(m >= 1 && m <= 100000);
        for (int i = 0 ; i < n ; i++) {
            scanf("%d",&req[i]);
            assert(req[i] >= 1 && req[i] <= 1000000000);
        }
        mp.clear();
        for (int32_t i = n - 1 ; i >= 0 ; --i) {
            if (mp.count(req[i])) {
                next[i] = mp[req[i]];
            } else {
                next[i] = n;
            }
            mp[req[i]] = i;
        }
        cache.clear();
        pos_in_cache.clear();
        for (int i = 1 ; i <= m ; ++i) {
            int tmp;
            if (mp.count(i)) tmp = mp[i];
            else tmp = n;
            pair<CacheItr, bool> res;
            res = cache.insert(make_pair(tmp, i));
            pos_in_cache[i] = res.first;
        }
        int ans = 0;
        for (int i = 0 ; i < n ; i++) {
            map<int, CacheItr>::iterator tmp_itr;
            tmp_itr = pos_in_cache.find(req[i]);
            if (tmp_itr != pos_in_cache.end()) {
                // hit
                CacheItr cache_itr = tmp_itr->second;
                CacheNode cache_node = *cache_itr;
                cache_node.first = next[i];
                cache.erase(cache_itr);
                pair<CacheItr, bool> res;
                res = cache.insert(cache_node);
                pos_in_cache[req[i]] = res.first;
            } else {
                // miss
                ++ans;
                if (next[i] < cache.rbegin()->first) {
                    // put into cache
                    CacheNode tmp_node;
                    tmp_node.first = next[i];
                    tmp_node.second = req[i];
                    std::pair<CacheItr, bool> res;
                    res = cache.insert(tmp_node);
                    pos_in_cache[req[i]] = res.first;
                    assert(res.second == true);
                    // remove least frequent
                    int least_req = cache.rbegin()->second;
                    pos_in_cache.erase(least_req);
                    cache.erase(--cache.end());
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}
