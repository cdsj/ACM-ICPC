#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>

const int T = 20;
int a[100100];

int rand32() {
    assert(RAND_MAX == 32767);
    return (rand() << 15) + rand();
}

int main() {
    freopen("data.in","w",stdout);
    srand(0x111);
    int n, m;
    for (int ca = 0 ; ca < T ; ++ca) {
        if (ca < T - 1) {n = 100; m = rand() % 20 + 10;}
        else {n = 100000; m = 10000;}
        for (int i = 0 ; i < n ; i++)
            a[i] = rand32() % (m * 3) + 1;
        printf("%d %d\n",n,m);
        for (int i = 0 ; i < n ; i++) {
            if (i) printf(" ");
            printf("%d",a[i]);
        }
        printf("\n");
    }
    return 0;
}
